window.alert=function () {
    console.log(arguments)
    return true;
}
window.alert("fuck")
